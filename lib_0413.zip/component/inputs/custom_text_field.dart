import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';

class CustomTextField extends StatelessWidget {
  final TextEditingController controller;
  final String hintText;
  final ValueChanged<String>? onChanged;
  final Color? backgroundColor;
  final double borderRadius;
  final TextInputType? keyboardType;
  final bool obscureText;
  final double height;
  final Widget? suffix;
  final FocusNode? focusNode;
  final Key? inputKey;
  final bool enabled;
  final List<TextInputFormatter>? inputFormatters;
  final TextStyle? style;

  const CustomTextField({
    Key? key,
    this.focusNode,
    this.inputKey,
    required this.controller,
    required this.hintText,
    this.onChanged,
    this.backgroundColor,
    this.borderRadius = 12.0,
    this.keyboardType,
    this.obscureText = false,
    this.height = 60.0,
    this.suffix,
    this.enabled = true,
    this.inputFormatters,
    this.style,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final Color bgColor =
        backgroundColor ??
        (controller.text.isEmpty
            ? (isDark ? theme.colorScheme.surface : AppColors.greyBackground)
            : (isDark ? theme.colorScheme.surface : AppColors.lightBlue));

    final TextStyle baseStyle = style ?? AppTextStyles.paragraph;
    final TextStyle effectiveStyle = isDark && style == null
        ? baseStyle.copyWith(color: theme.colorScheme.onSurface)
        : baseStyle;
    final Color hintColor = isDark
        ? theme.colorScheme.onSurfaceVariant
        : AppColors.subText;

    return Container(
      height: height,
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(borderRadius),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      alignment: Alignment.center,
      child: TextFormField(
        key: inputKey,
        focusNode: focusNode,
        controller: controller,
        style: effectiveStyle,
        textAlignVertical: TextAlignVertical.center,
        enabled: enabled,
        decoration: InputDecoration(
          isCollapsed: false,
          isDense: true,
          hintText: hintText,
          hintStyle: (style ?? AppTextStyles.paragraph).copyWith(
            color: hintColor,
          ),
          border: InputBorder.none,
          suffixIcon: suffix,
        ),
        onChanged: onChanged,
        keyboardType: keyboardType,
        obscureText: obscureText,
        inputFormatters: inputFormatters,
      ),
    );
  }
}
