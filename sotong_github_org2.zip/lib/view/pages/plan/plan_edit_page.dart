import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

// UI
import 'package:sotong_local/component/appbars/custom_app_bar.dart';
import 'package:sotong_local/component/texts/subtext.dart';
import 'package:sotong_local/view/pages/plan/plan_widgets/plan_edit/edit_summary_tile.dart';
import 'package:sotong_local/view/pages/plan/plan_widgets/plan_edit/minimal_field.dart';
import '../../../component/buttons/custom_button.dart';
import '../../../component/chart/fl_donut_colored_budget.dart';
import '../../../component/theme/app_colors.dart';

// Models / VMs
import '../../../model/refData/entry.dart';
import '../../../model/plan/plan_edit_result.dart';
import '../../../model/plan/total_plan.dart';
import '../../../model/refData/ref_data.dart';
import '../../../repository/plan_repository.dart';
import '../../../repository/ref_data_repository.dart';
import '../../../view_model/plan/chat_plan_viewmodel.dart';
import '../../../view_model/plan/plan_edit_viewmodel.dart';

// Modals
import 'package:sotong_local/view/pages/plan/plan_widgets/plan_input_modal/input_modal_widget.dart';

class PlanEditPage extends StatefulWidget {
  final TotalPlan? initialPlan;
  final RefData? initialRefData;
  final bool useLocalDraft;

  const PlanEditPage({
    Key? key,
    this.initialPlan,
    this.initialRefData,
    this.useLocalDraft = false,
  }) : super(key: key);

  @override
  State<PlanEditPage> createState() => _PlanEditPageState();
}

class _PlanEditPageState extends State<PlanEditPage> {
  int _selectedTabIndex = 0;
  final NumberFormat _nf = NumberFormat.decimalPattern('ko_KR');
  Future<_PlanEditInitData>? _initialFuture;
  TotalPlan? _basePlan;
  DateTime? _originalEndDate;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    if (widget.useLocalDraft) {
      _basePlan = widget.initialPlan;
      _originalEndDate = widget.initialPlan?.endDate;
    } else {
      _initialFuture = _loadInitialData();
    }
  }

  void _ensureOverrideDatePrompt(
      BuildContext context,
      PlanEditViewModel vm,
      ) {
    if (_overrideDatePrompted) return;
    _overrideDatePrompted = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final selected = await _pickOverrideToday(context, vm);
      if (!mounted) return;
      vm.setOverrideToday(selected ?? DateTime.now());
    });
  }

  Future<DateTime?> _pickOverrideToday(
      BuildContext context,
      PlanEditViewModel vm,
      ) async {
    final now = DateTime.now();
    final planStartSource = vm.totalPlan.startDate ?? now;
    final planStart = DateTime(
      planStartSource.year,
      planStartSource.month,
      planStartSource.day,
    );
    final goalSource = vm.projectedGoalDate ??
        vm.totalPlan.modEndDate ??
        vm.totalPlan.endDate ??
        planStart.add(const Duration(days: 365));
    DateTime planEnd = DateTime(goalSource.year, goalSource.month, goalSource.day);
    if (planEnd.isBefore(planStart)) {
      planEnd = planStart;
    }
    DateTime initial = DateTime(now.year, now.month, now.day);
    if (initial.isBefore(planStart)) {
      initial = planStart;
    }
    if (initial.isAfter(planEnd)) {
      initial = planEnd;
    }
    return showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: planStart,
      lastDate: planEnd,
      helpText: '적용할 날짜를 선택하세요',
    );
  }

  double _parseController(TextEditingController c) =>
      double.tryParse(c.text.replaceAll(',', '')) ?? 0.0;

  bool _overrideDatePrompted = false;

  Future<_PlanEditInitData> _loadInitialData() async {
    final planRepo = context.read<PlanRepository>();
    final refRepo = context.read<RefDataRepository>();
    TotalPlan? plan = widget.initialPlan ?? await planRepo.getLatestPlanForCurrentUser();
    if (plan == null) {
      throw StateError('편집할 플랜이 없습니다.');
    }
    final refData = widget.initialRefData ?? await refRepo.loadAll();
    refData.planId = plan.planId;
    return _PlanEditInitData(plan: plan, refData: refData);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  /// 저장 비활성 사유 (짧은 메시지)
  String? _blockingMessage(PlanEditViewModel vm) {
    final income = vm.monthlyIncome;
    final fixed = vm.monthlyFixedCost;
    final daily30 = vm.dailySpendingLimit * 30.0;
    final leftover = income - fixed;
    final monthlySaving = income - fixed - daily30;

    final target = _parseController(vm.targetAmountController);
    final current = _parseController(vm.currentAssetController);

    if (income <= 0) return '월 수입을 입력해주세요!';
    if (fixed > income || daily30 > (leftover > 0 ? leftover : 0) || monthlySaving <= 0) {
      return '소비가 수입을 초과했어요!';
    }
    if (target > 0 && current >= target) return '보유 자산이 목표 금액을 넘었어요!';
    return null;
  }

  // ----------------- 모달 -----------------
  Future<void> _openIncomeModal(BuildContext context, PlanEditViewModel vm) async {
    List<Entry>? stagedEntries;
    await showDialog(
      context: context,
      useRootNavigator: false,
      barrierDismissible: false,
      barrierColor: Colors.transparent,
      builder: (ctx) {
        return Material(
          type: MaterialType.transparency,
          child: InputModalWidget(
            isOpen: true,
            onClose: () => Navigator.of(ctx).pop(),
            title: '월 수입 입력하기',
            placeholder: '수입 카테고리',
            type: EntryType.fixed,
            initialEntries: vm.currentMonthlyIncomeEntries,
            onComplete: (items, total) {
              stagedEntries = List<Entry>.from(items);
            },
          ),
        );
      },
    );
    if (!mounted || stagedEntries == null) return;

    vm.applyFixedIncomeEdit(entries: stagedEntries!);
  }

  Future<void> _openFixedCostModal(BuildContext context, PlanEditViewModel vm) async {
    List<Entry>? stagedEntries;
    await showDialog(
      context: context,
      useRootNavigator: false,
      barrierDismissible: false,
      barrierColor: Colors.transparent,
      builder: (ctx) {
        return Material(
          type: MaterialType.transparency,
          child: InputModalWidget(
            isOpen: true,
            onClose: () => Navigator.of(ctx).pop(),
            title: '고정 소비 입력하기',
            placeholder: '고정 소비 항목',
            type: EntryType.fixed,
            initialEntries: vm.currentMonthlyConsumeEntries,
            onComplete: (items, total) {
              stagedEntries = List<Entry>.from(items);
            },
          ),
        );
      },
    );
    if (!mounted || stagedEntries == null) return;

    vm.applyFixedConsumeEdit(entries: stagedEntries!);
  }

  Future<void> _openDailyModal(BuildContext context, PlanEditViewModel vm) async {
    List<Entry>? stagedEntries;
    await showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.transparent,
      builder: (ctx) {
        // ✅ 월 잔여 예산 = 월수입 - 고정소비 (음수면 0으로 보정)
        final double leftover = (vm.monthlyIncome - vm.monthlyFixedCost);
        final double availableMonthly = leftover > 0 ? leftover : 0.0;

        return Material(
          type: MaterialType.transparency,
          child: InputModalWidget(
            isOpen: true,
            onClose: () => Navigator.of(ctx).pop(),
            title: '하루 사용 금액',
            placeholder: '하루 소비 항목',
            type: EntryType.daily,
            initialEntries: vm.currentDailyConsumeEntries,
            monthlyIncome: availableMonthly,
            onComplete: (items, total) {
              stagedEntries = List<Entry>.from(items);
            },
          ),
        );
      },
    );
    if (!mounted || stagedEntries == null) return;

    vm.applyDailyConsumeEdit(entries: stagedEntries!);
  }

  // ----------------- 저장 -----------------
  Future<void> _save(PlanEditViewModel vm) async {
    final msg = _blockingMessage(vm);
    if (msg != null) return;

    final validationError = vm.getValidationError();
    if (validationError != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(validationError), backgroundColor: AppColors.redText),
      );
      return;
    }

    final plan = _basePlan ?? widget.initialPlan ?? vm.totalPlan;
    vm.createUpdatedPlan(plan);
    if (_originalEndDate != null) {
      vm.totalPlanVM.plan = vm.totalPlanVM.plan.copyWith(endDate: _originalEndDate);
      vm.totalPlan = vm.totalPlanVM.plan;
    }

    final result = vm.finalizeEdits();
    vm.reloadWith(plan: result.updatedPlan, refData: result.updatedRefData);
    Navigator.of(context).pop(result);
  }

  // ----------------- UI -----------------
  @override
  Widget build(BuildContext context) {
    if (widget.useLocalDraft) {
      final plan = widget.initialPlan;
      final ref = widget.initialRefData;
      if (plan == null || ref == null) {
        return const Scaffold(
          body: Center(child: Text('편집할 플랜 데이터가 없습니다.')),
        );
      }
      _basePlan = plan;
      _originalEndDate = plan.endDate;
      return _buildEditorScaffold(plan: plan, refData: ref);
    }
    _initialFuture ??= _loadInitialData();
    return FutureBuilder<_PlanEditInitData>(
      future: _initialFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (!snapshot.hasData || snapshot.hasError) {
          return Scaffold(
            appBar: const PreferredSize(
              preferredSize: Size.fromHeight(kToolbarHeight),
              child: CustomAppBar(title: ''),
            ),
            body: Center(
              child: Text(
                snapshot.hasError
                    ? '플랜을 불러오지 못했습니다. 잠시 후 다시 시도해주세요.'
                    : '편집할 플랜이 없습니다.',
              ),
            ),
          );
        }
        final data = snapshot.data!;
        _basePlan = data.plan;
        _originalEndDate = data.plan.endDate;
        return _buildEditorScaffold(plan: data.plan, refData: data.refData);
      },
    );
  }

  Widget _buildEditorScaffold({
    required TotalPlan plan,
    required RefData refData,
  }) {
    return ChangeNotifierProvider(
      create: (_) => PlanEditViewModel(
        plan,
        initialRefData: refData,
      ),
      child: Builder(
        builder: (context) {
          final vm = context.read<PlanEditViewModel>();
          _ensureOverrideDatePrompt(context, vm);
          return Scaffold(
            appBar: const PreferredSize(
              preferredSize: Size.fromHeight(kToolbarHeight),
              child: CustomAppBar(title: ''),
            ),
            backgroundColor: Colors.white,
            body: SafeArea(
              child: Column(
                children: [
                  // 상단: 차트 또는 경고 배너(대체 표시)
                  const Padding(
                    padding: EdgeInsets.fromLTRB(24, 0, 24, 28),
                    child: _SyncBridgeForChartOrAdvice(),
                  ),

                  _buildTabBar(),

                  // ▼▼▼ 스크롤 가능한 영역 ▼▼▼
                  Expanded(
                    child: PrimaryScrollController(
                      controller: _scrollController,
                      child: Scrollbar(
                        controller: _scrollController,
                        thumbVisibility: false,
                        child: SingleChildScrollView(
                          controller: _scrollController,
                          padding: const EdgeInsets.only(bottom: 5),
                          child: Column(
                            children: [
                              IndexedStack(
                                index: _selectedTabIndex,
                                children: const [
                                  _PlanBasicInfoTab(),
                                  _UserInfoTab(),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                  // 저장 버튼
                  Consumer<PlanEditViewModel>(
                    builder: (context, vm, _) {
                      final canSave = vm.isValidForm() && _blockingMessage(vm) == null;
                      return Padding(
                        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                        child: CustomButton(
                          text: '저장',
                          enabled: canSave,
                          onPressed: canSave ? () => _save(vm) : () {},
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ------------ 탭바 ------------
  Widget _buildTabBar() {
    return Center(
      child: Container(
        width: MediaQuery.of(context).size.width * 0.5,
        decoration: BoxDecoration(
          color: const Color(0xFFF8F9FA),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Expanded(child: _buildTabButton('플랜 기본정보', 0)),
            Expanded(child: _buildTabButton('사용자 정보', 1)),
          ],
        ),
      ),
    );
  }

  Widget _buildTabButton(String text, int index) {
    final isSelected = _selectedTabIndex == index;
    return InkWell(
      onTap: () {
        setState(() => _selectedTabIndex = index);
      },
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          boxShadow: isSelected
              ? [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 8,
              offset: const Offset(0, 2),
            )
          ]
              : null,
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 10,
            fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
            color: isSelected ? Colors.black : const Color(0xFF6C757D),
          ),
        ),
      ),
    );
  }
}

/// =========================
/// 차트 or 경고 배너 (대체 렌더)
/// =========================
class _SyncBridgeForChartOrAdvice extends StatefulWidget {
  const _SyncBridgeForChartOrAdvice({Key? key}) : super(key: key);

  @override
  State<_SyncBridgeForChartOrAdvice> createState() =>
      _SyncBridgeForChartOrAdviceState();
}

class _SyncBridgeForChartOrAdviceState
    extends State<_SyncBridgeForChartOrAdvice> {
  Timer? _debounce;
  String _lastSignature = '';

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  // 변경점 시그니처
  String _makeSignature(PlanEditViewModel vm) {
    double _parse(String s) => double.tryParse(s.replaceAll(',', '')) ?? 0.0;

    final inc = vm.monthlyIncome;
    final fix = vm.monthlyFixedCost;
    final dly = vm.dailySpendingLimit;
    final target = _parse(vm.targetAmountController.text);
    final current = _parse(vm.currentAssetController.text);

    double _sum(List<Entry> xs) => xs.fold(0.0, (p, e) => p + e.amount);
    return [
      inc.toStringAsFixed(2),
      fix.toStringAsFixed(2),
      dly.toStringAsFixed(2),
      target.toStringAsFixed(2),
      current.toStringAsFixed(2),
      vm.currentMonthlyIncomeEntries.length,
      _sum(vm.currentMonthlyIncomeEntries).toStringAsFixed(2),
      vm.currentMonthlyConsumeEntries.length,
      _sum(vm.currentMonthlyConsumeEntries).toStringAsFixed(2),
      vm.currentDailyConsumeEntries.length,
      _sum(vm.currentDailyConsumeEntries).toStringAsFixed(2),
    ].join('|');
  }

  void _syncNow(
      BuildContext context,
      PlanEditViewModel editVM,
      ChatPlanViewModel chatVM,
      ) {
    double _parse(String s) => double.tryParse(s.replaceAll(',', '')) ?? 0.0;

    chatVM.updatePlanInfo(
      planName: editVM.planNameController.text,
      targetAmount: _parse(editVM.targetAmountController.text),
      currentAsset: _parse(editVM.currentAssetController.text),
      fixedIncomeSum: editVM.monthlyIncome,
      fixedConsumptionSum: editVM.monthlyFixedCost,
      dailyConsumptionSum: editVM.dailySpendingLimit,
    );
    chatVM.calculate();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<PlanEditViewModel, ChatPlanViewModel>(
      builder: (context, editVM, chatVM, _) {
        final sig = _makeSignature(editVM);
        if (sig != _lastSignature) {
          _lastSignature = sig;
          _debounce?.cancel();
          _debounce = Timer(const Duration(milliseconds: 80), () {
            if (mounted) _syncNow(context, editVM, chatVM);
          });
        }

        final calc = chatVM.calculationResult ?? chatVM.calculate();

        // 문제 여부 판정
        final income = editVM.monthlyIncome;
        final fixed = editVM.monthlyFixedCost;
        final daily = editVM.dailySpendingLimit;
        final daily30 = daily * 30.0;
        final leftover = income - fixed;
        final monthlySaving = income - fixed - daily30;

        double _parse(String s) => double.tryParse(s.replaceAll(',', '')) ?? 0.0;
        final target = _parse(editVM.targetAmountController.text);
        final current = _parse(editVM.currentAssetController.text);

        final List<_AdviceItem> issues = [];
        String _fmt(num v) =>
            NumberFormat.decimalPattern('ko_KR').format(v.round());

        if (income <= 0) {
          issues.add(
            _AdviceItem(
              title: '월 수입이 0원이에요.',
              tips: const [
                '수입 항목을 입력해 주세요',
                '정확한 금액이 어렵다면 추정치로 입력도 OK',
              ],
            ),
          );
        }
        if (fixed > income) {
          issues.add(
            _AdviceItem(
              title: '고정소비가 수입을 초과했어요.',
              subtitle:
              '고정소비 ${_fmt(fixed)}원 > 수입 ${_fmt(income)}원',
              tips: const ['고정 소비 점검', '수입 항목 추가 고려'],
            ),
          );
        } else if (daily30 > (leftover > 0 ? leftover : 0)) {
          issues.add(
            _AdviceItem(
              title: '하루 소비(×30)가 남는 금액을 초과했어요.',
              subtitle:
              '남는 금액 ${_fmt(leftover)}원, 변동소비 ${_fmt(daily30)}원',
              tips: const ['하루 한도를 낮추기', '고정소비 줄이기', '수입 늘리기 검토'],
            ),
          );
        } else if (monthlySaving <= 0) {
          issues.add(
            _AdviceItem(
              title: '현재 설정으로 월 저축액이 0원 이하예요.',
              subtitle: '월저축 = 수입 − 고정 − 변동',
              tips: const ['하루 한도를 5~10% 낮추기', '불필요한 구독/고정비 정리'],
            ),
          );
        }
        if (target > 0 && current >= target) {
          issues.add(
            _AdviceItem(
              title: '보유 자산이 목표 금액을 넘었어요.',
              subtitle:
              '보유 ${_fmt(current)}원 ≥ 목표 ${_fmt(target)}원',
              tips: const ['목표 금액 상향', '해당 목표 달성 처리'],
            ),
          );
        }

        if (issues.isNotEmpty) {
          return _BudgetAdviceBanner(items: issues);
        }

        // ✅ 차트에 들어갈 값도 여기서 계산
        final double variableCost = daily30;
        final double savingForChart =
        (income - fixed - variableCost) > 0 ? (income - fixed - variableCost) : 0.0;

        return RepaintBoundary(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 도넛 차트
              FlDonutColoredBudgetChart(
                income: income,
                fixed: fixed,
                variable: variableCost,
                saving: savingForChart,
                centerSpace: 30,
                chartHeight: 120,
              ),
              const SizedBox(height: 50),

              _PlanStatsBelowChart(
                reachDateStr: editVM.reachDateStr,
                durationStr: editVM.durationStr,
                canSave: editVM.dailyNetSaving > 0,
                hasGoal: (editVM.parsedTarget > editVM.parsedCurrent),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// =========================
/// 탭 1: 플랜 기본정보
/// =========================
class _PlanBasicInfoTab extends StatelessWidget {
  const _PlanBasicInfoTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Consumer<PlanEditViewModel>(
      builder: (context, vm, _) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              MinimalField(
                label: '플랜 이름',
                controller: vm.planNameController,
                hint: '예: 여름휴가 프로젝트',
                onChanged: (_) {},
              ),
              MinimalField(
                label: '목표 금액',
                controller: vm.targetAmountController,
                isNumber: true,
                hint: '예: 10,000,000',
                onChanged: (_) {},
              ),
              MinimalField(
                label: '보유 자산',
                controller: vm.currentAssetController,
                isNumber: true,
                hint: '예: 5,000,000 또는 -300,000',
                onChanged: (_) {},

              ),
            ],
          ),
        );
      },
    );
  }
}

/// =========================
/// 탭 2: 사용자 정보 (EditSummaryTile)
/// =========================
class _UserInfoTab extends StatelessWidget {
  const _UserInfoTab({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final page = context.findAncestorStateOfType<_PlanEditPageState>()!;
    return Consumer<PlanEditViewModel>(
      builder: (context, vm, _) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              EditSummaryTile(
                label: '월 수입',
                total: vm.monthlyIncome,
                onEdit: () => page._openIncomeModal(context, vm),
              ),
              EditSummaryTile(
                label: '고정 소비',
                total: vm.monthlyFixedCost,
                onEdit: () => page._openFixedCostModal(context, vm),
              ),
              EditSummaryTile(
                label: '하루 소비 한도 금액',
                total: vm.dailySpendingLimit,
                unit: '원',
                onEdit: () => page._openDailyModal(context, vm),
              ),
              const SizedBox(height: 30),
            ],
          ),
        );
      },
    );
  }
}

/// =========================
/// 경고 배너 + 아이템
/// =========================
class _BudgetAdviceBanner extends StatelessWidget {
  final List<_AdviceItem> items;
  const _BudgetAdviceBanner({Key? key, required this.items}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFEF2F2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFECACA)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.error_outline, size: 18, color: Color(0xFFDC2626)),
              SizedBox(width: 6),
              Text(
                '예산을 조정해 주세요',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFFDC2626),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ...items.take(3).map((e) => _AdviceTile(item: e)),
          if (items.length > 3)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                '외 ${items.length - 3}개 항목 더 있음',
                style:
                const TextStyle(fontSize: 12, color: Color(0xFF6B7280)),
              ),
            ),
        ],
      ),
    );
  }
}

class _AdviceItem {
  final String title;
  final String? subtitle;
  final List<String> tips;
  _AdviceItem({required this.title, this.subtitle, required this.tips});
}

class _AdviceTile extends StatelessWidget {
  final _AdviceItem item;
  const _AdviceTile({Key? key, required this.item}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SubText(
                  text: item.title,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                if (item.subtitle != null) ...[
                  const SizedBox(height: 4),
                  SubText(text: item.subtitle!),
                ],
                const SizedBox(height: 4),
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: item.tips.map((t) {
                    return Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: SubText(
                        text: t,
                        color: AppColors.redText,
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// =========================
/// 차트 하단 한 줄 (목표 도달 예정일 텍스트)
/// =========================
class _PlanStatsBelowChart extends StatelessWidget {
  final String? reachDateStr;
  final String? durationStr;
  final bool hasGoal;
  final bool canSave;

  const _PlanStatsBelowChart({
    Key? key,
    required this.reachDateStr,
    required this.durationStr,
    required this.hasGoal,
    required this.canSave,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final show =
        hasGoal && canSave && reachDateStr != null && durationStr != null;

    if (show) {
      return Align(
        alignment: Alignment.center,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.flag_rounded,
                size: 16, color: Colors.black54),
            const SizedBox(width: 6),
            RichText(
              text: TextSpan(
                style: const TextStyle(
                    fontSize: 13,
                    color: Colors.black87,
                    height: 1.2),
                children: [
                  const TextSpan(text: '목표 도달 예정일: '),
                  TextSpan(
                    text: reachDateStr!,
                    style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return const SizedBox.shrink();
  }
}

class _PlanEditInitData {
  const _PlanEditInitData({
    required this.plan,
    required this.refData,
  });

  final TotalPlan plan;
  final RefData refData;
}
