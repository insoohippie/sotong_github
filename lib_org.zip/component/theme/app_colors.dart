import 'package:flutter/material.dart';

class AppColors {
  // static const Color primary = Color(0xFF0062FF); // 메인 파란색
  static const Color primary = Color(0xFF3C7BFF); // 메인 파란색
  static const Color background = Colors.white; // 배경색

  static const Color greyBackground = Color(0xFFEDEDED); // 입력 전 입력창 배경
  static const Color lightBlue = Color(0xFFEDF4FF); // 파스텔 파랑 (입력창 배경)
  static const Color planTagBackground = Color(0xFFBBD5FF); //

  static const Color redBackground = Color(0xFFFFF5F5);
  static const Color redText = Color(0xFFDC2626);

  static const Color text = Colors.black; // 기본 텍스트
  static const Color subText = Color(0xFF9A9A9A); // 서브 텍스트
  static const Color error = Colors.red; // 에러 메시지
  static const Color whiteText = Colors.white; // 흰색 텍스트

  static const Color disabled = Color(0xFFDDDDDD); // 비활성화 버튼 회색
  static const Color darkBlue = Color(0xFF00368C); // 어두운 파랑
}
